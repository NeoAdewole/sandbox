<?php
function clearblocks_setup_theme()
{
  add_image_size('teamMember', 56, 56, true);
  add_image_size('openGraph', 1200, 630, true);
}
